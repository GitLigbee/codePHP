<?php
class A {}
$a = new A;
var_dump($a);